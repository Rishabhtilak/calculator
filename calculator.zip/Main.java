import java.util.*;
class Main{
    public static int myNum(int a , int b){
        int c = a +b;
        System.out.println(c);
        return 1;
    }
    public static int myNum2(int a , int b){
        int c = a *b;
        System.out.println(c);
        return 1;}
        
        public static int myNum3(int a , int b){
        int c = b-a;
        System.out.println(c);
        return 1;
        }
        public static int myNum4(int a , int b){
        int c = a +b;
        System.out.println(c);
        return 1;
}
public static void main(String[] args){
    Scanner sc = new Scanner (System.in);
    System.out.println("Write your oparands");
    int a = sc.nextInt();
    int b =sc.nextInt();
   
   System.out.println("PRESS 1 FOR ADDITION 2 FOR MULTPLICATION 3 FOR SUBSTRACTION 4 FOR DIVISION");
int ch = sc.nextInt();
    
    if(ch == 1){
        myNum(a,b);
    }else if (ch==2){
        myNum2(a,b);
        
    }else if (ch ==3){
        myNum3(a,b);
    }else if(ch ==4){
        myNum4(a,b);
    }else{
        System.out.println("invalid choice");
    }
}
}
    
    
    
    
